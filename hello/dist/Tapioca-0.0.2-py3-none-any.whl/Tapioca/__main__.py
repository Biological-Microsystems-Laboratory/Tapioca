from Tapioca.toga_gui import ImageEditor

if __name__ == '__main__':
    editor = ImageEditor()
    editor.run()